# PHANTOM CARDS starter
Responsive storefront for Crypto, Access, and Gift Cards.

## Run
Node.js 20+, then `npm install` and `npm start`.

## Railway
Upload the extracted project files to GitHub and connect that repository to Railway. Add `PAYSTACK_SECRET_KEY` as a Railway server-side variable; never put it in browser code or GitHub. Use Paystack test keys first.

## Before real sales
This starter begins Paystack checkout but does not yet implement verified payment callbacks/webhooks, saved orders, admin inventory, or secure one-time redemption. Do not deliver codes until these are implemented and tested. Product names/prices are sample listings, not real inventory. Sell only cards you own or are authorized to resell.
